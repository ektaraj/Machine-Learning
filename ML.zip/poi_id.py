#!/usr/bin/python
from __future__ import division
import sys
import pickle
sys.path.append("../tools/")

import pandas as pd

from feature_format import featureFormat, targetFeatureSplit
from tester import dump_classifier_and_data, test_classifier
import matplotlib.pyplot

from sklearn import tree    
from sklearn.naive_bayes import GaussianNB   
from sklearn.neighbors import KNeighborsClassifier 
from sklearn.ensemble import RandomForestClassifier
from sklearn.pipeline import Pipeline
from sklearn.decomposition import PCA
from sklearn.model_selection import GridSearchCV



### Task 1: Select what features you'll use.
### features_list is a list of strings, each of which is a feature name.
### The first feature must be "poi".
features_list = ['poi','salary', 'deferral_payments', 'total_payments','bonus',  
                 'total_stock_value', 'expenses', 'loan_advances',
                 'exercised_stock_options', 'long_term_incentive',
                 'to_messages','from_poi_to_this_person', 
                 'from_messages',
                 'from_this_person_to_poi', 'shared_receipt_with_poi',
                 'proportion_from_poi','proportion_to_poi','expenses_salary']



''' The following features have been added to the features_list but they have not been 
# defined at this moment. They are assigned value in a few moments. Keep reading!

#'proportion_from_poi',
#'proportion_to_poi',
#'expenses_salary' '''

### Load the dictionary containing the dataset
with open("final_project_dataset.pkl", "r") as data_file:
    data_dict = pickle.load(data_file)

### Task 2: Remove outliers

# A separate feature list, to detect outliers

features_for_outliers = ["salary", "bonus"] 
data = featureFormat(data_dict, features_for_outliers)

print("-------Detecting outliers--------")

# This peice of code is written to draw a scatter plot of salary vs bonus.

for point in data:
    salary = point[0]
    bonus = point[1]
    matplotlib.pyplot.scatter( salary, bonus)


matplotlib.pyplot.xlabel("salary")
matplotlib.pyplot.ylabel("bonus")
matplotlib.pyplot.savefig("th.png")
matplotlib.pyplot.show()

# Following datapoints are outliers, which are being removed from the dataset.
data_dict.pop('TOTAL')
data_dict.pop('THE TRAVEL AGENCY IN THE PARK')
data_dict.pop('LOCKHART EUGENE E')


print("--------After cleaning outliers--------")

# Having the outliers cleaned, now we again draw a scatter plot of salary vs bonus.

data = featureFormat(data_dict, features_for_outliers)
for point in data:
    salary = point[0]
    bonus = point[1]
    matplotlib.pyplot.scatter( salary, bonus)


matplotlib.pyplot.xlabel("salary")
matplotlib.pyplot.ylabel("bonus")
matplotlib.pyplot.savefig("pt.png")
matplotlib.pyplot.show()

############################################################################################

### Task 3: Create new feature(s)


'''
We are engineering the following features with the help of given features:
    
'proportion_from_poi',
'proportion_to_poi',
'expenses_salary'

'''



for k, v in data_dict.iteritems():
#Assigning value to the feature 'proportion_from_poi'

    if v['from_poi_to_this_person'] != 'NaN' and  v['from_messages'] != 'NaN':
        v['proportion_from_poi'] = v['from_poi_to_this_person'] / v['from_messages'] 
    else:    
        v['proportion_from_poi'] = 0.0
        
for k, v in data_dict.iteritems():
#Assigning value to the feature 'proportion_to_poi'        
    if v['from_this_person_to_poi'] != 'NaN' and  v['to_messages'] != 'NaN':
        v['proportion_to_poi'] = v['from_this_person_to_poi'] / v['to_messages']   
    else:
        v['proportion_to_poi'] = 0.0
        
for k, v in data_dict.iteritems():
#Assigning value to the feature 'expenses_salary'        
    if v['expenses'] != 'NaN' and  v['salary'] != 'NaN':
         v['expenses_salary'] = v['expenses'] / v['salary']
    else:
        v['expenses_salary'] = 0.0
       
       
###########################################################################################        
        
# EXPLORING THE DATASET BY CONVERTING IT INTO DATAFRAME       

df = pd.DataFrame.from_dict(data_dict, orient='index', dtype=None)
#print(df.head(5))

print("\n\n-----About the dataset-----")  

print "Number of data points = ",len(df)
print "Total number of features(original+engineered)", len(df.columns)

#Here I am finding number of poi in the dataset   
poi_num = 0
for i in (df['poi']):
    if i == True:
        poi_num=poi_num+1
print "Number of person of interest in the dataset = ", poi_num

#Here I am finding number of missing values in each feature    
for col in df.columns:
    nan= 0
    for i in df[col]:
        if i == 'NaN':
            nan = nan+1          
    print "Number of missing values in "+ col + "\t", nan
    
###############################################################################################
### Store to my_dataset for easy export below.
my_dataset = data_dict

##############################################################################################

### Extract features and labels from dataset for local testing
data = featureFormat(my_dataset, features_list, sort_keys = True)
labels, features = targetFeatureSplit(data)


###############################################################################################

#selecting K best features

from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import f_classif


kbest = [2,3,4,5,6,7,8,10,'all']
for i in kbest:
    skb = SelectKBest(f_classif, k = i)
    skb.fit_transform(features,labels)
    feature_scores =  skb.scores_
    # making list of K best features and their corresponding score.
    best_features = [features_list[j] for j in skb.get_support(indices = True)]
    selected_score = [feature_scores[m] for m in skb.get_support(indices = True)]
     
    print("FEATURES = ",best_features)
    print("SCORES = ",selected_score)
    print"mean features score when k = ", i,
    print"=", sum(selected_score)/len(selected_score)
    print("\n\n")

'''We choose the features obtained when K = 5.

For K = 5, the best features and its score is as follows'''

best_features = ['poi', 'total_payments', 'bonus', 'loan_advances', 
                 'exercised_stock_options']
selected_score = [18.003739993113935, 20.524645181851792, 23.898259813869416, 
                  24.532722463057976, 9.7721035384082544]

print("\n\n-----Best Features extracted using SelectKBest------")
print(best_features)
print("[Feature ---- Feature Score]")

for i in range(len(best_features)):
   print(best_features[i]+"----"),
   print(selected_score[i])
    
print("\n\n-----Features I engineered------")    

manual_select  = ['proportion_to_poi', 'proportion_from_poi',
                 'expenses_salary']
print(manual_select)

print("\n\n-----Features used in this analysis-----")  
print(best_features)

#best_features = ['poi','bonus', 'loan_advances']
#best_features = ['poi', 'total_payments', 'bonus', 'loan_advances']
#best_features = ['poi', 'total_payments', 'bonus', 'loan_advances', 'exercised_stock_options']
#best_features = ['poi', 'deferral_payments', 'total_payments', 'bonus', 'loan_advances', 'exercised_stock_options']
#best_features = ['poi', 'deferral_payments', 'total_payments', 'bonus', 'loan_advances', 'exercised_stock_options', 'from_this_person_to_poi']
#best_features = ['poi', 'deferral_payments', 'total_payments', 'bonus', 'expenses', 'loan_advances', 'exercised_stock_options', 'from_this_person_to_poi']
#best_features = ['poi', 'deferral_payments', 'total_payments', 'bonus', 'total_stock_value', 'expenses', 'loan_advances', 'exercised_stock_options', 'to_messages', 'from_this_person_to_poi']
#best_features = ['poi', 'salary', 'deferral_payments', 'total_payments', 'bonus', 'total_stock_value', 'expenses', 'loan_advances', 'exercised_stock_options', 'long_term_incentive', 'to_messages', 'from_poi_to_this_person', 'from_messages', 'from_this_person_to_poi', 'shared_receipt_with_poi', 'proportion_from_poi', 'proportion_to_poi']
###################################################################################

data = featureFormat(my_dataset, best_features, sort_keys = True)
nlabels, nfeatures = targetFeatureSplit(data)


### Task 4: Try a varity of classifiers
### Please name your classifier clf for easy export below.
### Note that if you want to do PCA or other multi-stage operations,
### you'll need to use Pipelines. For more info:
### http://scikit-learn.org/stable/modules/pipeline.html

# Provided to give you a starting point. Try a variety of classifiers.

#==============================================================================
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
features_train, features_test, labels_train, labels_test = train_test_split(nfeatures, nlabels, test_size=0.3)
# Deploying feature scaling using MinMaxScaler method
scaler = MinMaxScaler().fit(features_train)
train_scaled = scaler.transform(features_train)
test_scaled = scaler.transform(features_test)
# 
#==============================================================================

def try_classifiers(model):
    '''
    this function fits each model I used
    '''
    fit_model = model.fit(train_scaled, labels_train)
    #test_classifier(fit_model, my_dataset, best_features)
    
    '''UNCOMMENT ABOVE LINE TO TEST EACH CLASSIFIER I TRIED''' 
    
    return fit_model

#==============================================================================

print("\n\n----Trying different classifiers----")    

clf = try_classifiers(model = GaussianNB())    

clf = try_classifiers(model = tree.DecisionTreeClassifier(random_state = 0))

clf = try_classifiers(model = KNeighborsClassifier(n_neighbors = 3))

clf = try_classifiers(RandomForestClassifier(class_weight='balanced', random_state = 42, bootstrap = True, n_jobs = 3))                                         

#Pipelining PCA and Naive Bayes 
estimator = [("pca",PCA(n_components=2)), ("clf", GaussianNB())]
clf = try_classifiers(model = Pipeline(estimator))



#==============================================================================
### Task 5: Tune your classifier to achieve better than .3 precision and recall 
### using our testing script. Check the tester.py script in the final project
### folder for details on the evaluation method, especially the test_classifier
### function. Because of the small size of the dataset, the script uses
### stratified shuffle split cross validation. For more info: 
### http://scikit-learn.org/stable/modules/generated/sklearn.cross_validation.StratifiedShuffleSplit.html




#==============================================================================
#tuning prarameter with GridSearchCV for KNeighborsClassifier
param_grid = { 
    'n_neighbors': [3,5],
    'metric': ['manhattan','euclidean','chebyshev'],
    } 
clf = KNeighborsClassifier()
gs = GridSearchCV(clf, param_grid=param_grid, verbose=0, scoring = 'f1')
model = gs.fit(train_scaled, labels_train)
test_classifier(model.best_estimator_, my_dataset, best_features)

#==============================================================================
#The best classifier among the above is found to be:
#KNeighborsClassifier

clf = KNeighborsClassifier(n_neighbors = 3, metric = 'manhattan')

#==============================================================================

#Try investigating other evaluation techniques!
print("\n\n--------Validation--------")

'''I have used StratifiedShuffleSplit cross-validation to validate the chosen model'''
from sklearn.model_selection import StratifiedShuffleSplit
from sklearn.model_selection import cross_val_score

sss = StratifiedShuffleSplit(n_splits=3, test_size=0.5, random_state=0)
print "\n Cross Validation Score"
print(cross_val_score(clf, nfeatures, nlabels, cv = sss))

#==============================================================================

### Task 6: Dump your classifier, dataset, and features_list so anyone can
### check your results. You do not need to change anything below, but make sure
### that the version of poi_id.py that you submit can be run on its own and
### generates the necessary .pkl files for validating your results.

dump_classifier_and_data(clf, my_dataset, best_features)
